import React from 'react';
import { motion } from 'framer-motion';
import { 
  GraduationCap, Code, DollarSign, 
  Plane, Languages, Target 
} from 'lucide-react';

const Home = () => {
  const goals = [
    {
      icon: <GraduationCap className="w-6 h-6" />,
      title: "Academic",
      description: "Maintain 3.0+ GPA, reach 3.3 by end of 2nd year",
      color: "bg-blue-500"
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: "Career",
      description: "Progress from Front-end to Full-stack/Flutter development",
      color: "bg-purple-500"
    },
    {
      icon: <DollarSign className="w-6 h-6" />,
      title: "Financial",
      description: "Earn $4000+ through freelancing by September 2025",
      color: "bg-green-500"
    },
    {
      icon: <Plane className="w-6 h-6" />,
      title: "Location",
      description: "Relocate to USA (Green Card goal)",
      color: "bg-red-500"
    },
    {
      icon: <Languages className="w-6 h-6" />,
      title: "Skills",
      description: "Enhance English speaking/listening abilities",
      color: "bg-yellow-500"
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
        <div className="relative px-8 py-16 md:px-12 md:py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl font-bold mb-4">
              Hi, I'm Anar 👋
            </h1>
            <p className="text-xl mb-6 text-indigo-100">
              2nd-year Computer Engineering student at ADNSU, passionate about technology and personal growth.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="px-6 py-2 bg-white text-indigo-600 rounded-lg font-medium hover:bg-indigo-50 transition-colors">
                View Roadmap
              </button>
              <button className="px-6 py-2 bg-transparent border-2 border-white text-white rounded-lg font-medium hover:bg-white/10 transition-colors">
                Contact Me
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Goals Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.map((goal, index) => (
          <motion.div
            key={goal.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6"
          >
            <div className={`inline-block p-3 rounded-lg ${goal.color} text-white mb-4`}>
              {goal.icon}
            </div>
            <h3 className="text-xl font-semibold mb-2">{goal.title}</h3>
            <p className="text-gray-600">{goal.description}</p>
          </motion.div>
        ))}
      </section>

      {/* Quick Stats */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-2">Technical Progress</h3>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '45%' }}></div>
          </div>
          <p className="text-sm text-gray-600 mt-2">45% towards Full-stack</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-2">Freelance Income</h3>
          <div className="text-3xl font-bold text-green-600">$1,250</div>
          <p className="text-sm text-gray-600">Monthly average</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-2">Current GPA</h3>
          <div className="text-3xl font-bold text-blue-600">3.2</div>
          <p className="text-sm text-gray-600">Target: 3.3</p>
        </div>
      </section>
    </div>
  );
};

export default Home;