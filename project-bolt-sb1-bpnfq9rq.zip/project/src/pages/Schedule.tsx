import React from 'react';
import { motion } from 'framer-motion';
import { Clock, BookOpen, Code, Dumbbell, Brain, Coffee, Moon, Briefcase } from 'lucide-react';

const Schedule = () => {
  const schedule = [
    {
      time: "07:00 - 08:00",
      activity: "Morning Routine",
      description: "Wake up, meditation, light exercise, breakfast",
      icon: <Coffee className="w-5 h-5" />,
      color: "bg-yellow-500"
    },
    {
      time: "08:00 - 10:00",
      activity: "Technical Development",
      description: "Front-end fundamentals / Advanced coding practice",
      icon: <Code className="w-5 h-5" />,
      color: "bg-blue-500"
    },
    {
      time: "10:00 - 12:00",
      activity: "University Studies",
      description: "Online lectures, assignments, personal development",
      icon: <BookOpen className="w-5 h-5" />,
      color: "bg-green-500"
    },
    {
      time: "13:30 - 18:00",
      activity: "University Classes",
      description: "Attend lectures, participate in discussions",
      icon: <Brain className="w-5 h-5" />,
      color: "bg-purple-500"
    },
    {
      time: "19:00 - 20:00",
      activity: "Physical Exercise",
      description: "Gym session / Home workout",
      icon: <Dumbbell className="w-5 h-5" />,
      color: "bg-red-500"
    },
    {
      time: "21:00 - 23:00",
      activity: "Freelance Work",
      description: "Client projects and skill development",
      icon: <Briefcase className="w-5 h-5" />,
      color: "bg-indigo-500"
    },
    {
      time: "23:00 - 24:00",
      activity: "Evening Routine",
      description: "Review, planning, and relaxation",
      icon: <Moon className="w-5 h-5" />,
      color: "bg-gray-500"
    }
  ];

  return (
    <div className="space-y-8">
      <header className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-3xl font-bold mb-4">Daily Schedule</h1>
        <p className="text-gray-600">
          Optimized daily routine for maximum productivity and balanced growth
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {schedule.map((item, index) => (
          <motion.div
            key={item.time}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${item.color} text-white`}>
                {item.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-sm font-medium text-gray-500">
                    {item.time}
                  </span>
                </div>
                <h3 className="text-lg font-semibold mb-1">{item.activity}</h3>
                <p className="text-gray-600 text-sm">{item.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Schedule;