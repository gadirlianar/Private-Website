import React from 'react';
import { motion } from 'framer-motion';
import { 
  GraduationCap, Briefcase, Heart,
  Target, Download, ExternalLink
} from 'lucide-react';

const About = () => {
  return (
    <div className="space-y-8">
      {/* Profile Section */}
      <section className="bg-white rounded-xl shadow-sm p-8">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="w-full md:w-1/3">
            <img
              src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400&h=400"
              alt="Profile"
              className="w-full h-auto rounded-xl shadow-md"
            />
          </div>
          <div className="w-full md:w-2/3">
            <h1 className="text-3xl font-bold mb-4">About Me</h1>
            <p className="text-gray-600 mb-6">
              I'm a passionate Computer Engineering student at ADNSU, dedicated to becoming a skilled
              full-stack developer. My journey combines academic excellence with practical experience
              in software development, focusing on creating impactful solutions that make a difference.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-colors">
                <Download className="w-4 h-4" />
                Download Resume
              </button>
              <button className="flex items-center gap-2 px-6 py-2 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 transition-colors">
                <ExternalLink className="w-4 h-4" />
                View Portfolio
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Background & Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            Education
          </h2>
          <div className="space-y-4">
            <div className="border-l-2 border-indigo-600 pl-4">
              <h3 className="font-medium">Computer Engineering</h3>
              <p className="text-sm text-gray-600">ADNSU • 2022 - Present</p>
              <p className="text-sm text-gray-600">GPA: 3.2/4.0</p>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-600" />
            Experience
          </h2>
          <div className="space-y-4">
            <div className="border-l-2 border-indigo-600 pl-4">
              <h3 className="font-medium">Freelance Developer</h3>
              <p className="text-sm text-gray-600">Self-employed • 2023 - Present</p>
              <p className="text-sm text-gray-600">Front-end development projects</p>
            </div>
          </div>
        </section>
      </div>

      {/* Skills & Interests */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-600" />
            Technical Skills
          </h2>
          <div className="space-y-4">
            {[
              { name: 'HTML/CSS', level: 90 },
              { name: 'JavaScript', level: 85 },
              { name: 'React', level: 80 },
              { name: 'Node.js', level: 60 },
              { name: 'Flutter', level: 40 }
            ].map((skill) => (
              <div key={skill.name}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">{skill.name}</span>
                  <span className="text-sm text-gray-600">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-indigo-600 h-2 rounded-full" 
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Heart className="w-5 h-5 text-indigo-600" />
            Interests & Values
          </h2>
          <div className="flex flex-wrap gap-2">
            {[
              'Software Development',
              'AI & Machine Learning',
              'Mobile Development',
              'Cloud Computing',
              'Open Source',
              'Tech Education',
              'Problem Solving',
              'Continuous Learning'
            ].map((interest) => (
              <span
                key={interest}
                className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm"
              >
                {interest}
              </span>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;