import React from 'react';
import { motion } from 'framer-motion';
import { Milestone, Code, Book, Trophy } from 'lucide-react';

const Roadmap = () => {
  const phases = [
    {
      title: "Front-end Fundamentals",
      period: "0-6 Months",
      items: [
        "Master HTML5, CSS3, and JavaScript ES6+",
        "Deep dive into React and TypeScript",
        "Learn responsive design principles",
        "Build portfolio projects"
      ],
      progress: 65
    },
    {
      title: "Full-stack Transition",
      period: "6-24 Months",
      items: [
        "Node.js and Express.js fundamentals",
        "Database design with PostgreSQL",
        "RESTful API development",
        "Flutter mobile development"
      ],
      progress: 30
    },
    {
      title: "Advanced Specialization",
      period: "2+ Years",
      items: [
        "System design and architecture",
        "Cloud services (AWS/Azure)",
        "DevOps practices",
        "Advanced mobile development"
      ],
      progress: 10
    }
  ];

  return (
    <div className="space-y-8">
      <header className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-3xl font-bold mb-4">Development Roadmap</h1>
        <p className="text-gray-600">
          A structured path from front-end development to full-stack expertise,
          with clear milestones and progress tracking.
        </p>
      </header>

      <div className="space-y-6">
        {phases.map((phase, index) => (
          <motion.div
            key={phase.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
              <div className="flex-1">
                <h2 className="text-xl font-semibold">{phase.title}</h2>
                <p className="text-sm text-gray-600">{phase.period}</p>
              </div>
              <div className="w-full md:w-64">
                <div className="flex justify-between text-sm mb-1">
                  <span>Progress</span>
                  <span>{phase.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${phase.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
            <ul className="space-y-3">
              {phase.items.map((item, itemIndex) => (
                <li key={itemIndex} className="flex items-start gap-3">
                  <div className="mt-1">
                    <div className="w-2 h-2 bg-indigo-600 rounded-full"></div>
                  </div>
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Roadmap;