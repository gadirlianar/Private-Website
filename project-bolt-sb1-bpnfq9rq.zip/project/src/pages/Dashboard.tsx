import React from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, Brain, DollarSign, 
  Target, Award, BookOpen 
} from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="space-y-8">
      <header className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-3xl font-bold mb-4">Personal Dashboard</h1>
        <p className="text-gray-600">
          Track your progress across academic, technical, and personal goals
        </p>
      </header>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-lg">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">GPA</h3>
              <p className="text-sm text-gray-600">Academic Progress</p>
            </div>
          </div>
          <div className="text-3xl font-bold text-blue-600">3.2</div>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '80%' }}></div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-green-100 text-green-600 rounded-lg">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Income</h3>
              <p className="text-sm text-gray-600">Monthly Freelancing</p>
            </div>
          </div>
          <div className="text-3xl font-bold text-green-600">$1,250</div>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-green-600 h-2 rounded-full" style={{ width: '60%' }}></div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-lg">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Skills</h3>
              <p className="text-sm text-gray-600">Technical Progress</p>
            </div>
          </div>
          <div className="text-3xl font-bold text-purple-600">45%</div>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-purple-600 h-2 rounded-full" style={{ width: '45%' }}></div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Progress Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {[
              { title: "Completed React Course", date: "2 days ago", icon: <BookOpen className="w-4 h-4" /> },
              { title: "Freelance Project Delivered", date: "5 days ago", icon: <Award className="w-4 h-4" /> },
              { title: "Technical Assessment Passed", date: "1 week ago", icon: <TrendingUp className="w-4 h-4" /> }
            ].map((activity, index) => (
              <div key={index} className="flex items-start gap-4">
                <div className="p-2 bg-gray-100 rounded-lg text-gray-600">
                  {activity.icon}
                </div>
                <div>
                  <h3 className="font-medium">{activity.title}</h3>
                  <p className="text-sm text-gray-600">{activity.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Upcoming Goals</h2>
          <div className="space-y-4">
            {[
              { title: "Complete Node.js Course", deadline: "2 weeks left", progress: 75 },
              { title: "Launch Portfolio Website", deadline: "1 month left", progress: 60 },
              { title: "Flutter App Development", deadline: "3 months left", progress: 30 }
            ].map((goal, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between">
                  <h3 className="font-medium">{goal.title}</h3>
                  <span className="text-sm text-gray-600">{goal.deadline}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${goal.progress}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;