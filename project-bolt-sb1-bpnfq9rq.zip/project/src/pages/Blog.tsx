import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, User, Clock, Tag } from 'lucide-react';

const Blog = () => {
  const posts = [
    {
      title: "My Journey into Full-stack Development",
      excerpt: "Reflecting on my transition from front-end to full-stack development, sharing key learnings and challenges.",
      date: "March 15, 2024",
      readTime: "5 min read",
      tags: ["Development", "Career"],
      image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=800&h=400"
    },
    {
      title: "Balancing University and Freelancing",
      excerpt: "How I manage my time between academic responsibilities and building a freelance career.",
      date: "March 10, 2024",
      readTime: "4 min read",
      tags: ["Productivity", "Education"],
      image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=800&h=400"
    }
  ];

  return (
    <div className="space-y-8">
      <header className="bg-white rounded-xl shadow-sm p-8">
        <h1 className="text-3xl font-bold mb-4">Blog</h1>
        <p className="text-gray-600">
          Thoughts, experiences, and insights from my journey
        </p>
      </header>

      <div className="space-y-6">
        {posts.map((post, index) => (
          <motion.article
            key={post.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm overflow-hidden"
          >
            <img
              src={post.image}
              alt={post.title}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag) => (
                  <span
                    key={tag}
                    className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm"
                  >
                    <Tag className="w-3 h-3" />
                    {tag}
                  </span>
                ))}
              </div>
              <h2 className="text-2xl font-bold mb-3">{post.title}</h2>
              <p className="text-gray-600 mb-4">{post.excerpt}</p>
              <div className="flex items-center gap-4 text-sm text-gray-500">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{post.readTime}</span>
                </div>
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  );
};

export default Blog;